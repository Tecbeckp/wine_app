import 'package:flutter/material.dart';

class AppColors{
  static const primary = Color(0xFF7D0B7F);
  static const black = Color(0xFF000000);
  static const oringeChatColor = Color(0xFFD3833A);
  static const appBarBlackContainer = Color(0xFF010000);
  static const heartContainer = Color(0xFF7D0B7F);
  static const dateTime = Color(0xFF001521);


}