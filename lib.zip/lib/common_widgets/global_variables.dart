import 'package:flutter/material.dart';

final imagepath = ValueNotifier("");