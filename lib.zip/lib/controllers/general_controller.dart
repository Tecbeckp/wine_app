import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';


class GeneralController extends GetxController {
  RxInt backgroundImageCounter = 0.obs;

}
